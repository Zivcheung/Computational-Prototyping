package com.thomasdiewald.pixelflow.java.dwgl;

import com.thomasdiewald.pixelflow.java.DwPixelFlow;

public class DwGLTextureCube {

//  static private int TEX_COUNT = 0;

  public DwPixelFlow context;
//  private GL2ES2 gl;

  public int[] HANDLE = null;

  public DwGLTextureCube(){
    System.out.println("TODO: implement DwGLTextureCube");
  }
  
  
}
